var class_x___o___board =
[
    [ "X_O_Board", "class_x___o___board.html#aff75cefd426f1e8db38555ed9b59fee8", null ],
    [ "game_is_over", "class_x___o___board.html#aaee6e3efcbd685d9792d6d81356bba45", null ],
    [ "is_draw", "class_x___o___board.html#a2be5f37643e21edbdea2361853a6e953", null ],
    [ "is_lose", "class_x___o___board.html#aec0358cc4f109084267b953832478e94", null ],
    [ "is_win", "class_x___o___board.html#aafb56a8db5bf8352157326a52c06e2e6", null ],
    [ "update_board", "class_x___o___board.html#aef2b0da670b2d5dc6333e0e0113f8b3d", null ]
];