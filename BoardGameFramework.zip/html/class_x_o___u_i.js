var class_x_o___u_i =
[
    [ "XO_UI", "class_x_o___u_i.html#a3777235b2b66dc912258a4ee20501ebb", null ],
    [ "~XO_UI", "class_x_o___u_i.html#a6c58a77a2fa80f73e7076ca4a94fcc8a", null ],
    [ "get_move", "class_x_o___u_i.html#a4814913b14a2666667a2a90ab8205356", null ]
];