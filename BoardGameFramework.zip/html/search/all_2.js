var searchData=
[
  ['display_5fboard_5fmatrix_0',['display_board_matrix',['../class_u_i.html#a5d4655d5ff273e284fd68b8547483a23',1,'UI']]],
  ['display_5fmessage_1',['display_message',['../class_u_i.html#a1eead148ee8726b8ea329c2cd8841d18',1,'UI']]]
];
