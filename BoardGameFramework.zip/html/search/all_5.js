var searchData=
[
  ['main_0',['main',['../_x_o___demo_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'XO_Demo.cpp']]],
  ['move_1',['Move',['../class_move.html',1,'Move&lt; T &gt;'],['../class_move.html#a100102cb072a2857304023233dac7b42',1,'Move::Move()']]]
];
