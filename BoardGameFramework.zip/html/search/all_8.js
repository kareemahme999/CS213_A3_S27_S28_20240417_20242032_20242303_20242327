var searchData=
[
  ['rows_0',['rows',['../class_board.html#a948d978e3b5fc460559b588f5dee9572',1,'Board']]],
  ['run_1',['run',['../class_game_manager.html#a71f46d5189dac5c773f608cea1b5a203',1,'GameManager']]]
];
