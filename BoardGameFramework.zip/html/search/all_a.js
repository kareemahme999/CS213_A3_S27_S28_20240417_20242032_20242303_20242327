var searchData=
[
  ['type_0',['type',['../class_player.html#a81a15b1b507fd5f2157fb15bf0fd283f',1,'Player']]]
];
