var searchData=
[
  ['x_5fo_5fboard_0',['X_O_Board',['../class_x___o___board.html',1,'']]],
  ['xo_5fui_1',['XO_UI',['../class_x_o___u_i.html',1,'']]]
];
