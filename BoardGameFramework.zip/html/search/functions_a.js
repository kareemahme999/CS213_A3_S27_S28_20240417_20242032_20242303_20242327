var searchData=
[
  ['x_5fo_5fboard_0',['X_O_Board',['../class_x___o___board.html#aff75cefd426f1e8db38555ed9b59fee8',1,'X_O_Board']]],
  ['xo_5fui_1',['XO_UI',['../class_x_o___u_i.html#a3777235b2b66dc912258a4ee20501ebb',1,'XO_UI']]]
];
