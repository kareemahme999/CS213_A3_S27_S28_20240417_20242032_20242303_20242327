var searchData=
[
  ['board_0',['board',['../class_board.html#af00c1fc363eb640ca276b8a572040040',1,'Board']]],
  ['boardptr_1',['boardPtr',['../class_player.html#a26249e756f850b6585267bfbc928ac79',1,'Player']]]
];
